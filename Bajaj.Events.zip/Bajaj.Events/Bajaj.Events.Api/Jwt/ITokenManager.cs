﻿using Bajaj.Events.Models;

namespace Bajaj.Events.Api.Jwt
{
    public interface ITokenManager
    {
        string GenerateAccessToken(User user,string roleName);
        string GenerateRefreshToken(User user, string roleName);
    }
}
