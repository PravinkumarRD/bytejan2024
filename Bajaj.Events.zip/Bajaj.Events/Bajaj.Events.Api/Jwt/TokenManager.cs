﻿using System.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Bajaj.Events.Models;
using Microsoft.IdentityModel.Tokens;

namespace Bajaj.Events.Api.Jwt
{
    public class TokenManager : ITokenManager
    {
        private readonly IConfiguration _configuration;
        private readonly SymmetricSecurityKey _key;

        public TokenManager(IConfiguration configuration)
        {
            _configuration = configuration;
            _key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Bajaj:TokenSecret"]));
        }
        public string GenerateAccessToken(User user, string roleName)
        {
            var claims = new List<Claim>{
                new Claim(ClaimTypes.Email,user.UserName),
                new Claim(ClaimTypes.Role,roleName),
            };
            var credentials = new SigningCredentials(_key, SecurityAlgorithms.HmacSha256Signature);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddSeconds(20),
                SigningCredentials = credentials
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        public string GenerateRefreshToken(User user, string roleName)
        {
            throw new NotImplementedException();
        }
    }
}
