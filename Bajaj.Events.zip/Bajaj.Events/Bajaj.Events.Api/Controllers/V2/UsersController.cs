﻿using AutoMapper;
using Bajaj.Events.Api.DTOs.UserDtos;
using Bajaj.Events.Api.Jwt;
using Bajaj.Events.Dal;
using Bajaj.Events.Dal.Authentication;
using Bajaj.Events.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bajaj.Events.Api.Controllers.V2
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IAuthenticationRepository _authenticationRepository;
        private readonly ICommonRepository<User> _usersRepository;
        private readonly IMapper _mapper;
        private readonly ITokenManager _tokenManager;
        public UsersController(IAuthenticationRepository authenticationRepository, IMapper mapper, ICommonRepository<User> commonRepository, ITokenManager tokenManager)
        {
            _authenticationRepository = authenticationRepository;
            _mapper = mapper;
            _usersRepository = commonRepository;
            _tokenManager = tokenManager;
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<UserDetailsDto>> Get(int id)
        {
            var user = await _usersRepository.GetDetailAsync(id);
            if (user != null)
            {
                return Ok(user);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<User>> Post(NewUserDto userDto)
        {
            if (ModelState.IsValid)
            {
                var user = _mapper.Map<User>(userDto);
                int result = await _authenticationRepository.RegisterUser(user);
                if (result > 0)
                {
                    return CreatedAtAction("Get", new { id = user.UserId }, user);
                }
            }
            else
            {
                return BadRequest();
            }
            return BadRequest();
        }
        [HttpPost("login")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<AuthenticationResponse>> AuthenticateUser(NewUserDto userDto)
        {
            if (ModelState.IsValid)
            {
                var user = _mapper.Map<User>(userDto);
                var response = await _authenticationRepository.AuthenticateCredentials(user);
                if (response.IsAuthenticated)
                {
                    response.Token = _tokenManager.GenerateAccessToken(user, response.RoleName);
                    return Ok(response);
                }
                else
                {
                    return NotFound(response);
                }
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
