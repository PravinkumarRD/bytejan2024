﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Bajaj.Events.Api.Controllers.V2
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
    }
}
