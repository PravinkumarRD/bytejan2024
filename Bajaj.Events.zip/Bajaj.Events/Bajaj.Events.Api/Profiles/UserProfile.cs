﻿using AutoMapper;
using Bajaj.Events.Api.DTOs.UserDtos;
using Bajaj.Events.Models;

namespace Bajaj.Events.Api.Profiles
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<User, UserDetailsDto>();
            CreateMap<NewUserDto, User>();
        }
    }
}
