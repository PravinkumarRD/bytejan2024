﻿namespace Bajaj.Events.Api.DTOs.RoleDtos
{
    public class RoleDetailsDto
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; } = string.Empty;
        public string RoleDescription { get; set; } = string.Empty;
    }
}
