﻿namespace Bajaj.Events.Api.DTOs.RoleDtos
{
    public class RoleDto
    {
        public string RoleName { get; set; }=string.Empty;
        public string RoleDescription { get; set; } = string.Empty;
    }
}
