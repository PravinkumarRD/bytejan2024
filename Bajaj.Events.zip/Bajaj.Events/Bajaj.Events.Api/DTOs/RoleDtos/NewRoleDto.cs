﻿namespace Bajaj.Events.Api.DTOs.RoleDtos
{
    public class NewRoleDto
    {
        public string RoleName { get; set; } = string.Empty;
        public string RoleDescription { get; set; } = string.Empty;
    }
}
