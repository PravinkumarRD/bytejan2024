﻿using System.ComponentModel.DataAnnotations;

namespace Bajaj.Events.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        [Required(ErrorMessage = "Employee Name is required!")]
        [MaxLength(100, ErrorMessage = "Employee Name can not exceed 100 characters!")]
        public string EmployeeName { get; set; } = string.Empty;
        [Required(ErrorMessage = "Employee Address is required!")]
        [MaxLength(500, ErrorMessage = "Employee Address can not exceed 500 characters!")]
        public string Address { get; set; } = string.Empty;
        [Required(ErrorMessage = "Employee City is required!")]
        [MaxLength(50, ErrorMessage = "City can not exceed 50 characters!")]
        public string City { get; set; } = string.Empty;
        [MinLength(6, ErrorMessage = "Zipcode must be 6 characters!")]
        [MaxLength(6, ErrorMessage = "Zipcode must be 6 characters!")]
        public int Zipcode { get; set; }
        [Required(ErrorMessage = "Employee Country is required!")]
        [MaxLength(50, ErrorMessage = "Country can not exceed 50 characters!")]
        public string Country { get; set; } = string.Empty;
        [Required(ErrorMessage = "Employee Skillsets is required!")]
        [MaxLength(100, ErrorMessage = "Employee Skillsets can not exceed 100 characters!")]
        public string Skillsets { get; set; } = string.Empty;
        [Required(ErrorMessage = "Employee Email is required!")]
        [MaxLength(100, ErrorMessage = "Employee Email can not exceed 100 characters!")]
        [EmailAddress(ErrorMessage ="Please enter valid email Id!")]
        public string Email { get; set; } = string.Empty;
        [MaxLength(20, ErrorMessage = "Employee phone can not exceed 20 characters!")]
        public string Phone { get; set; } = string.Empty;
        [MaxLength(50, ErrorMessage = "Employee Department can not exceed 50 characters!")]
        public string Department { get; set; } = string.Empty;
        [MaxLength(100, ErrorMessage = "Employee Profile Pic Path can not exceed 100 characters!")]
        public string Avatar { get; set; } = string.Empty;
    }
}
