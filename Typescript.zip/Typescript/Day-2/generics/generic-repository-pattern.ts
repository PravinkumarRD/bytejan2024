//Generics/Templates can be used for method, property, class and interface implementation

interface ICommonRepository<T> {
    getAll(): T[];
    getDetails(id: number): T;
    insert(item: T): T;
    update(id: number, item: T): T;
    delete(id: number): void;
}

class CommonRepository<T> implements ICommonRepository<T> {
    private _localDb: Array<T> = new Array<T>();
    getAll(): T[] {
        return this._localDb;
    }
    getDetails(id: number): T {
        return this._localDb[0];
    }
    insert(item: T): T {
        this._localDb.push(item);
        return item;
    }
    update(id: number, item: T): T {
        throw new Error("Method not implemented.");
    }
    delete(id: number): void {
        throw new Error("Method not implemented.");
    }
}

class Employee {
    constructor(public employeeId: number, public employeeName: string, public city: string) {

    }
}
class Supplier {
    constructor(public supplierId: number, public supplierName: string, public city: string, public companyName: string) {

    }
}

const e1: Employee = new Employee(1001, "Manisha K.", "Pune");
const e2: Employee = new Employee(1002, "Alisha C.", "Mumbai");

const s1: Supplier = new Supplier(1, "John Mark", "London", "Detox Care");
const s2: Supplier = new Supplier(2, "Maria Andrus", "Berlin", "Cafe De Monto");

const employeesRepo: ICommonRepository<Employee> = new CommonRepository<Employee>();
employeesRepo.insert(e1);
employeesRepo.insert(e2);
console.log(employeesRepo.getAll());
console.log(employeesRepo.getDetails(e1.employeeId));

const supplierRepo:ICommonRepository<Supplier> = new CommonRepository<Supplier>();
supplierRepo.insert(s1);
supplierRepo.insert(s2);
console.log(supplierRepo.getAll());
console.log(supplierRepo.getDetails(e1.employeeId));
