//How to write a class?
//Answer - Write Function-As-A-Class and Constructor Function

function Person(fname, lname, city) {
  //public members
  this.firstName = fname;
  this.lastName = lname;
  this.city = city;
  this.getPersonInfo=function(){
    return "Person " + this.firstName + " " + this.lastName + " lives in city " + this.city + "!";
  }
  //private members
  var _socialId;
}

var p1=new Person("Pravin","R. D.","Pune");
console.log(p1.getPersonInfo());