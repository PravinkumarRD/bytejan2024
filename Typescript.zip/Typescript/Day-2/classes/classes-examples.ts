//Syntactic Sugar
//Classes created with class keyword will never polute the global scope
//Typescript supports Access Modifiers [Private, Public and Protected]. By default all the members of the class is public
/*
class Person {
    private _socialId: number;
    firstName: string;
    lastName: string;
    city: string;
    getPersonInfo(): string {
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}

class Person {
    constructor(fname: string, lname: string, city: string) {
        this.firstName = fname;
        this.lastName = lname;
        this.city = city;
    }
    private _socialId: number;
    firstName: string;
    lastName: string;
    city: string;
    getPersonInfo(): string {
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}

class Person {
    constructor(public firstName?: string,public lastName?: string,public city?: string) {
        
    }
    private _socialId: number;
    
    getPersonInfo(): string {
        
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}


class Person {
    constructor() {

    }
    private _socialId: number;
    private _firstName: string;
    get firstName() {
        console.log("Reading firstName property value!;");
        return this._firstName;
    }
    set firstName(value: string) {
        console.log("Writing firstName property value!;");
        this._firstName = value;
    }
    
    private _lastName : string;
    public get lastName() : string {
        return this._lastName;
    }
    public set lastName(v : string) {
        this._lastName = v;
    }
    
    private _city : string;
    public get city() : string {
        return this._city;
    }
    public set city(v : string) {
        this._city = v;
    }
    
    
    getPersonInfo(): string {

        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}
*/
//Generalization-To-Specialization [Inheritance]
//All general classes are implemented with the help of Abstract class
abstract class Person {
    constructor(public firstName?: string, public lastName?: string, public city?: string) {
        console.log('Parent Class Constructor Executed!');
    }
    private _socialId: number;
    address: string;
    getPersonInfo(): string {

        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
    abstract changeAddress(oldAddress: string, newAddress): boolean;
}

//IS-A = [Inheritance]
class Customer extends Person {
    constructor() {
        super();
        console.log('Child Class Constructor Executed!');
    }
    customerId: number;
    changeAddress(oldAddress: string, newAddress: any): boolean {
        console.log(`Person ${this.firstName} ${this.lastName} has changes his/her address from ${oldAddress} to ${newAddress}!`);
        return true;
    }

}

//const p1: Person = new Person();
const p1: Customer = new Customer();
p1.firstName = "Alisha";
p1.lastName = "C.";
p1.address = "East Zone, Seepz, Andheri, Mumbai";
p1.city = "Mumbai";
p1.changeAddress(p1.address, "North Zone, Hira Nandani, Andheri, Mumbai")
console.log(p1.getPersonInfo());


console.log(typeof (Person));

class Counter {
    private static count = 1;
    static incrementCounter(): number {
        return Counter.count++;
    }
}
console.log(Counter.incrementCounter());
console.log(Counter.incrementCounter());
console.log(Counter.incrementCounter());
console.log(Counter.incrementCounter());
class Fuel {
    gas: string;
    oil: string;
    isPetrol: boolean;
    isElectric: boolean;
    isCng: boolean;
    isDisel: boolean;
}
class Engine {
    engineMake: string;
    engineNumber: number;
    power: string;
    fuel: Fuel;
}
//Car has an Engine
class Car {
    carId: number;
    carModel: string;
    engine: Engine;
}

const myCar: Car = new Car();
myCar.carId = 1829;
myCar.carModel = "SUV";
myCar.engine.engineMake = "ABC";
myCar.engine.power = "700HP";
myCar.engine.fuel.isElectric = true;