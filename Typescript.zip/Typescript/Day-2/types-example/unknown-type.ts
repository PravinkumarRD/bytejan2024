let value: unknown;
value = 100;
value = true;
value=new Array(100);

let myLuckyNumber: unknown = value;