type Address = {
    roadNo?: number,
    roadName: string,
    area: string
}

const myAddress:Address={
    area:'Suncity',
    roadNo:1289,
    roadName:'Sinhgad Road'
}