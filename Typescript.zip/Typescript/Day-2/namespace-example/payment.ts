
namespace Payment {
    export namespace CashPayment {
        export function makePayment(customerId: number, cashAmount: number, orderId: number): string {
            return `Customer ${customerId} as made cash payment of INR ${cashAmount}/- for Order No ${orderId}!`;
        }
    }
    export namespace WalletPayment{

        export function makePayment(customerId: number, walletAmount: number, orderId: number, walletName: string): string {
            return `Customer ${customerId} as made wallet payment of INR ${walletAmount}/- for Order No ${orderId} using ${walletName}!`;
        }
    }
}
console.log(Payment.CashPayment.makePayment(23489,1200,829));
console.log(Payment.WalletPayment.makePayment(78122,12000,908,"Paytm"));