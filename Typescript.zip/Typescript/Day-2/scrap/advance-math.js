function square(num) {
  return addition(num, num) * 2;
}
