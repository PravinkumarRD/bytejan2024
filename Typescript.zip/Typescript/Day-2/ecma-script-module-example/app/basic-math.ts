console.log('Basic Math Module Started!');
import { square } from "./advance-math";
//Named exports
function addition(num1: number, num2: number): number {
    return num1 + num2;
}
function multiplication(num1: number, num2: number): number {
    return num1 * num2;
}
function subtraction(num1: number, num2: number): number {
    return num1 - num2;
}
function division(num1: number, num2: number): number {
    return num1 / num2;
}

console.log(`Square of 34 is - ${square(34)}!`);
export { addition, multiplication, subtraction, division, square }
console.log('Basic Math Module Loaded!');