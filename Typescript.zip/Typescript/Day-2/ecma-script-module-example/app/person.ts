console.log('Person Module Started!');
abstract class Person{
    constructor(){
        console.log("Person class constrcutor executed!");
    }
    firstName:string;
    lastName:string;
    city:string;
    getPersonInfo():string{
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}
export default Person;
console.log('Person Module Loaded!');