console.log('Customer Module Started!');
import BajajPerson from "./person";

class Customer extends BajajPerson {
    constructor(){
        super();
        console.log("Customer class constrcutor executed!");
    }
}

//Singleton pattern
//export default new Customer();

export default Customer;
console.log('Customer Module Loaded!');