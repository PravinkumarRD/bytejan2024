console.log('Main Module Started!');
//import { addition, multiplication, } from "./app/basic-math";
import * as BajajMath from "./app/basic-math";
import Customer from "./app/customer";

console.log(BajajMath.addition(100, 200));
console.log(BajajMath.square(89));
console.log(BajajMath.multiplication(100, 200));
const c1:Customer=new Customer();
c1.firstName="Alisha";
c1.lastName="C.";
c1.city="Mumbai";
console.log(c1.getPersonInfo());
const c2:Customer=new Customer();
c2.firstName="John";
c2.lastName="Mark";
c2.city="London";
console.log(c2.getPersonInfo());
console.log('Main Module Loaded!');