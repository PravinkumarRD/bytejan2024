function defaultValue(value: any) {
    return function (target, propertyKey: string) {
        console.log(target);
        console.log(propertyKey);
        console.log("Default value property decorator executed!");
        Object.defineProperty(target, propertyKey, {
            writable:true,
            enumerable:true,
            configurable:true,
            value
        });
    }
}

class Customer {
    constructor() {

    }
    @defaultValue(100)
    private _creditAmount: number;
    public get creditAmount(): number {
        console.log(this._creditAmount);
        return this._creditAmount;
    }
    public set creditAmount(v: number) {
        this._creditAmount = v;
    }
    getCreditAmount() {
        return this._creditAmount;
    }
}
const customer: Customer = new Customer();
console.log(customer.getCreditAmount());