function logger(constructor:Function) {
    console.log("Hello - Decorator Logger Executed!");
    console.log(constructor);
}

function logger1() {
    return function(constructor:Function){
        console.log("Decorator Logger Executed!!!!!");
        console.log(constructor);
    }
}

function logger2(message:string) {
    return function(constructor:Function){
        console.log(message);
        console.log(constructor);
    }
}

@logger
@logger1()
@logger2("Person class logger!")
class Person {
    constructor() {
        console.log("Person Constructor executed!");
    }
}
