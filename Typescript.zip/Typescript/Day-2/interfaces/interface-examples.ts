interface Biology {
    biologyCalci(): string;
}
interface Chemistry {
    chemistryCalci(): string;
}
interface Physics {
    physicsCalci(): string;
}
interface ScienceHod extends Biology, Chemistry, Physics {

}

class Science implements Biology, Physics, Chemistry {
    chemistryCalci(): string {
        throw new Error("Method not implemented.");
    }
    physicsCalci(): string {
        throw new Error("Method not implemented.");
    }
    biologyCalci(): string {
        throw new Error("Method not implemented.");
    }

}

const bio: Biology = new Science();
const chem: Chemistry = new Science();
const phys: Physics = new Science();
const hod: ScienceHod = new Science();

interface ProductSchema {
    productId: number;
    productName: string;
    unitPrice: number;
    isDiscontinued?: boolean;
}

class Product implements ProductSchema {
    productId: number;
    productName: string;
    unitPrice: number;
}

const MyProductsList: ProductSchema[] = [
    {
        productId: 2392,
        productName: "ABC",
        unitPrice: 293.90
    },
    {
        productId: 2393,
        productName: "DEF",
        unitPrice: 267.90,
        isDiscontinued: true

    },
];