enum Menu {
    AMERICAN = 1,
    JAPANESE,
    INDIAN,
    ITALIAN
}

const customerOrder: Menu = Menu.JAPANESE;

switch (+customerOrder) {
    case 1:
        console.log('Customer has ordered American Food!');
        break;

    case 2:
        console.log('Customer has ordered Japanese Food!');
        break;
    case 3:
        console.log('Customer has ordered Indian Food!');
        break;
    case 4:
        console.log('Customer has ordered Italian Food!');
        break;
    default:
        console.log("We don't server this Food!");
        break;
}