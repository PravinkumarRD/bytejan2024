//All the rules of let are applicable to const
const PI = 3.14;


const BajajCities = ["Bangalore", "Pune"];
BajajCities.push("Chennai");
console.log(BajajCities);
