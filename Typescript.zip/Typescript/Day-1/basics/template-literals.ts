const Customer = {
    customerId: 1272,
    contactName: "Manish Kaushik",
    city: "Raipur"
}
//Customer Manish Kaushik lives in city Raipur has Customer Id 1272!
//In ES5, String formatting!
console.log("Customer " + Customer.contactName + " \n\tlives in city " + Customer.city + " has Customer Id " + Customer.customerId + "!");

console.log("Customer %s lives in city %s has Customer Id %d!",Customer.contactName,Customer.city,Customer.customerId);

function getCustomerInfo(){
    //return "Customer " + Customer.contactName + " lives in city " + Customer.city + " has Customer Id " + Customer.customerId + "!";
    //return ("Customer %s lives in city %s has Customer Id %d!",Customer.contactName,Customer.city,Customer.customerId);
    return `Customer ${Customer.contactName} 
    lives in city ${Customer.city} has Customer Id ${Customer.customerId}!`
}
console.log(getCustomerInfo());

//Template Literals or Template Expression
//Syntax - backtick syntax - `static text ${expression}`
console.log(`Customer ${Customer.contactName} 
    lives in city ${Customer.city} has Customer Id ${Customer.customerId}!`);