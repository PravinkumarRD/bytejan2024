//searchProducts - byStock, byCompanyName
const Products = [
    {
        productId: 3829,
        productName: 'Apple 13 Pro',
        unitPrice: 97000,
        company: 'Apple',
        stock: 23
    },
    {
        productId: 3830,
        productName: 'Apple 14 Pro',
        unitPrice: 123000,
        company: 'Apple',
        stock: 45
    },
    {
        productId: 3831,
        productName: 'Samsung Galazy',
        unitPrice: 37000,
        company: 'Samsung',
        stock: 67
    },
    {
        productId: 3832,
        productName: 'Samsung Note',
        unitPrice: 77000,
        company: 'Samsung',
        stock: 50
    },
    {
        productId: 3833,
        productName: 'Nokia 7',
        unitPrice: 27000,
        company: 'Nokia',
        stock: 56
    }
];

function searchProducts(stock: number): string[];
function searchProducts(companyName: string): string[];
function searchProducts(value: number | string): string[] {
    const CopyOfProducts = [...Products];
    const FoundProducts = [];
    if (typeof (value) === 'number') {
        for (const product of CopyOfProducts) {
            if (product.stock > value) FoundProducts.push(product.productName);
        }
    }else{
        for (const product of CopyOfProducts) {
            if (product.company===value) FoundProducts.push(product.productName);
        }
    }
    return FoundProducts;
}

console.log(searchProducts(25));
console.log(searchProducts('Samsung'));