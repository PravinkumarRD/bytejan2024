//Type Inference - Typescript compiler will choose an appropriate type from the type system upon declaration and initiazation of the variable and will retain that type throughout the life of the application;
let num1 = 100;
//num1 = "100";
//num1 = true;

//Type Annotations
//let num2: number;
let num2: number | string;
num2 = 100;
num2 = "Pravinkumar";
//num2 = [];

function myAddition(num1: number, num2: number): number {
    return num1 + num2;
}
