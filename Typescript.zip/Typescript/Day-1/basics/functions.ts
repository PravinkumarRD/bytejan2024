// function addition(num1: number): number {
//     return num1 + 1000;
// }
function addition(num1: number, num2: number): number {
    return num1 + num2;
}

console.log(addition(100, 200));

//Optional Parameters in Typescript function. All optional parameters must be declared at the end of the parameters list!
/*function salesNetProfit(cogs: number, expense: number, actualSales: number, gstPercent?: number): number {
    if (!gstPercent) gstPercent = 0;
    const gstAmount: number = actualSales * gstPercent / 100;
    return actualSales - (cogs + expense + gstAmount);
}*/

//Default Parameters - Default parameters can come anywhere in the list of parameters
function salesNetProfit(cogs: number, expense: number = 15000, actualSales: number, gstPercent: number = 0): number {
    const gstAmount: number = actualSales * gstPercent / 100;
    return actualSales - (cogs + expense + gstAmount);
}

console.log(`Sales Net Profit without GST is INR ${salesNetProfit(12000, undefined, 150000)}/-`);
console.log(`Sales Net Profit with 18% GST is INR ${salesNetProfit(12000, 13000, 150000, 18)}/-`);

//Pass zero to unlimited parameter to the function
//REST Parameter - Will take comma separated values and pack them in an array

function getAllStateCities(state: string, ...cities: string[]): void {
    console.warn(`In State of - ${state} there is/are below list of cities - `)
    for (const city of cities) {
        console.log(city);
    }
}
getAllStateCities("Maharashtra", "Mumbai", "Nagar", "Pune");
console.warn("");

//SPREAD Operator - It unpacks the collection values [Array and Object]
const KACities: string[] = ["Bijapur", "Bangalore", "Humpi", "Badami"];
getAllStateCities("Karnatak", ...KACities);

const MyEmployee = {
    employeeId: 2389,
    employeeName: "Alisha C.",
    city: "Mumbai"
}

const YourEmployee = {
    ...MyEmployee
};
MyEmployee.city = "Delhi";
console.log(MyEmployee);
console.log(YourEmployee);