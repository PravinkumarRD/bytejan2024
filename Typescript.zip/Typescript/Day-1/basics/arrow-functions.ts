//Does not have binding with this keyword
//Most of the time, you will use them as callback functions

const BajajEmployee = {
    employeeId: 2389,
    employeeName: 'Manish Sharma',
    city: 'Pune',
    // printEmployeeInfo: function () {
    //     var _self = this;
    //     console.log(_self);
    //     setTimeout(function () {
    //         console.log(_self);
    //         console.log(`Employee ${_self.employeeName} lives in city ${_self.city}!`);
    //     }, 2000);
    // }
    // printEmployeeInfo: function () {
    //     console.log(this);
    //     setTimeout(function(){
    //         console.log(this);
    //         console.log(`Employee ${this.employeeName} lives in city ${this.city}!`);
    //     }.bind(this),2000);
    // }
    printEmployeeInfo: function () {
        console.log(this);
        setTimeout(()=>{
            console.log(this);
            console.log(`Employee ${this.employeeName} lives in city ${this.city}!`);
        },2000);
    }
}
BajajEmployee.printEmployeeInfo();