//Strongly Typed Array Declaration

const MyWorkingOfficeCities: (string | number)[] = ["Bangalore", "Chennai", "Pune", 411051];

const BajajCustomers =
    [
        {
            customerId: 1271,
            contactName: "Pravinkumar Dabade",
            city: "Pune"
        },
        {
            customerId: 1272,
            contactName: "Manish Kaushik",
            city: "Raipur"
        },
        {
            customerId: 1273,
            contactName: "Alisha C.",
            city: "Mumbai"
        }
    ];