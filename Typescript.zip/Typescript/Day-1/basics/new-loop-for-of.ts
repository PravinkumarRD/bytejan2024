const MyWorkingOffices: string[] = ["Bangalore", "Chennai", "Delhi", "Hyderabad"];

console.log("Too Complex Code!")
for (let index = 0; index < MyWorkingOffices.length; index++) {
    if (MyWorkingOffices[index] === "Delhi") break;
    console.log(MyWorkingOffices[index]);
}
console.log("Can not use break!")
MyWorkingOffices.forEach(city => {
    //if(city==="Delhi") continue;
    console.log(city);
});

console.log('New Loop in ES6/Typescript!');
//Behind this loop, the brain is Iterator object of ES6
for (const city of MyWorkingOffices) {
    if (city === "Delhi") break;
    console.log(city)
}

const result = MyWorkingOffices[Symbol.iterator]();
console.log(result.next());
console.log(result.next());
console.log(result.next());
console.log(result.next());
console.log(result.next());

