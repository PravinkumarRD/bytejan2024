//In ES5, there is no block scoping. You can scope the variables only by using functions

//Scoping in ES5
/*
{
    var x = 100;
}
console.log(x);
if (true) {
    var y = 200;
}
console.log(y);

for (var i = 0; i < 5; i++) {
    //some logic
}
console.log(i);

//Hoisting - In JavaScript, the variables and function will get hoisted during the compilation time.
//What is hoisting?
//JavaScript engine, will place the variables and function declarations into the memory during complilation phase of JavaScript
console.log(companyName);
var companyName = "Bajaj Ltd.";
//Re-declaration
var num1=100;
var num1="100";*/

//Block Scoping using let
{
    let x = 100;
}
//console.log(x);
if (true) {
    let y = 200;
}
//console.log(y);

for (let i = 0; i < 5; i++) {
    //some logic
}
//console.log(i);
//console.log(companyName);
let companyName = "Bajaj Ltd."; //Variables declared with let and const keywords, is hoisted in TDZ - Temporal Dead Zone area
console.log(companyName);
//No redeclaration of variables using let keyword within the same scope
let n1 = 100;
//let n1 = "200";